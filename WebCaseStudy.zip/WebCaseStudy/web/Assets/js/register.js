$(document).ready(function(){
    $("#save").on("click",Validate);
    function Validate(){
        var fname=$("#ufname").val();
        var lname=$("#ulname").val();
        var phone=$("#unum").val();
        var email=$("#umail").val();
        var pass=$("#upass").val();
        var address=$("#uaddress").val();
        var dob=$("#udob").val();
        var gender=$("#ugender:checked").val();
        var city=$("#ucity").val();
        var state=$("#ustate").val();
        var pin=$("#uzip").val();
        var country=$("#ucountry").val();
        if(fname===null || fname==="")
        {
            alert("Fill First Name");
            return false;
        }
         if(lname===null || lname==="")
        {
            alert("Fill Last Name");
            return false;
        }
        if(dob===null || dob==="")
        {
            alert("Enter date of birth");
            return false;
        }
         if(gender===null || gender==="")
        {
            alert("Select gender");
            return false;
        }
         if(phone===null || phone==="")
        {
            alert("Fill Phone Number");
            return false;
        }
         if(email===null || email==="")
        {
            alert("Enter Email");
            return false;
        }
         if(pass===null || pass==="")
        {
            alert("Enter Password");
            return false;
        }
         if(address===null || address==="")
        {
            alert("Fill address ");
            return false;
        }
        var name = fname + " " + lname;
        $.ajax({
            url:'userRegister',
            method:"POST",
            data:{name: name , dob: dob, gender: gender, phone: phone, email: email, pass: pass, address: address, city: city, state: state, pin: pin,country: country},
            dataType:"json",
            success:function(response)
            {
                if(response.status) {
                    alert("User Saved");
                    document.getElementById('registration-form').reset();
                } else {
                    alert(response.message);
                }
            },
            error:function()
            {
                alert('Cannot reach server!!!Try again later!!!');
            }
            
        });
    }
});



