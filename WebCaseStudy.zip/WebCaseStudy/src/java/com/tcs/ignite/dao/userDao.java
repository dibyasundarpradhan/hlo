/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.tcs.ignite.dao;

import com.tcs.ignite.bean.user;
import com.tcs.ignite.util.dbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONObject;

/**
 *
 * @author Dibya Sundar Pradhan
 */
public class userDao {
    Connection con=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    public JSONObject insertUser(user ub){
        JSONObject jobj=new JSONObject();
        try
        {
            dbConnection db=new dbConnection();
            con=db.getConnection();
            ps=con.prepareStatement("insert into user(name,dob,gender,phone,email,pass,address,city,state,pin,country) values(?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, ub.getName());
            ps.setString(2,ub.getDob());
            ps.setString(3, ub.getGender());
            ps.setString(4, ub.getPhone());
            ps.setString(5, ub.getEmail());
            ps.setString(6, ub.getPass());
            ps.setString(7,ub.getAddress());
            ps.setString(8, ub.getCity());
            ps.setString(9, ub.getState());
            ps.setInt(10, ub.getPin());
            ps.setString(11, ub.getCountry());
            Boolean flag=!ps.execute();
            jobj.put("status",flag);
            if(flag){
                jobj.put("message","Registered Successfully"); 
            }else{
                jobj.put("message","Somthing Went Wrong. Try Again Latter");
            }
        }catch(Exception e){
            e.printStackTrace();
            
        }
        finally{
            try{
                if(ps!=null){
                    ps.close();
                }
            }catch(SQLException e){
                e.printStackTrace();
            }
            try{
                if(con!=null){
                    con.close();
                }
            }catch(SQLException e){
                e.printStackTrace();
            }
            try{
                if(rs!=null){
                    rs.close();
                }
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
        return jobj;
        
    }
    
}
