/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.tcs.ignite.util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Dibya Sundar Pradhan
 */
public class dbConnection {
    public Connection getConnection()
    {
        Connection con=null;
        try{
            String driver="com.mysql.jdbc.Driver";
            String url="jdbc:mysql://localhost:3306/webcasestudy";
            String u_id="root";
            String pass="root";
            Class.forName(driver);
            con=DriverManager.getConnection(url,u_id,pass);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }
    public static void main(String[] args) {
         System.out.println(new dbConnection().getConnection());
    
    }
}

