/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.tcs.ignite.Servlet;

import com.tcs.ignite.bean.user;
import com.tcs.ignite.dao.userDao;
import org.json.JSONObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Dibya Sundar Pradhan
 */
public class userRegister extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pri=response.getWriter();
        JSONObject jsobj=new JSONObject();
        String userName=request.getParameter("name");
        String dob=request.getParameter("dob");
        String gender=request.getParameter("gender");
        String phone=request.getParameter("phone");
        String email=request.getParameter("email");
        String pass=request.getParameter("pass");
        String address=request.getParameter("address");
        String city=request.getParameter("city");
        String state=request.getParameter("state");
        int pin=Integer.parseInt(request.getParameter("pin"));
        String country=request.getParameter("country");
        user ub=new user();
        ub.setName(userName);
        ub.setDob(dob);
        ub.setGender(gender);
        ub.setPhone(phone);
        ub.setEmail(email);
        ub.setPass(pass);
        ub.setAddress(address);
        ub.setCity(city);
        ub.setState(state);
        ub.setPin(pin);
        ub.setCountry(country);
        userDao ud=new userDao();
        jsobj=ud.insertUser(ub);
        pri.print(jsobj);
    }
}
